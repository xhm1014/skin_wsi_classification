%---annotation---%
% The main function for organizing features from skin images
% University of Alberta
% Hongming Xu
%---end---%

function Features_Organization
clear all; clc;
cd C:\Users\Jorge\Dropbox\Public\Classification_Project_I\Features

%% Melanoma
load('melanoma.mat');   %%163
ObjectsFeatures=[];
for i=1:size(AllFeatures,2)
    Features=[];
    for j=1:size(AllFeatures,1)
        temp0=AllFeatures{j,i}; 
        
        % scaling to unit length
        %     for j=1:size(A,1)
        %         temp2=A(j,:)/norm(A(j,:));
        %     end
        % simpplest rescaling
%        An=rescaling(temp);

       temp1=struct2cell(temp0);
       temp2=cell2mat(temp1);
       temp2=reshape(temp2,[1 numel(temp2)]);
       Features=[Features,temp2];
    end
    ObjectsFeatures(i,:)=Features;
end
FIdx=size(ObjectsFeatures,1);
CasePoolIdx{1}=[1:FIdx];
lastIdx=FIdx+1;

%% Nevus
load('nevus.mat');%%65
for i=1:size(AllFeatures,2)
    Features=[];
    for j=1:size(AllFeatures,1)
        temp0=AllFeatures{j,i}; 
        
        % scaling to unit length
        %     for j=1:size(A,1)
        %         temp2=A(j,:)/norm(A(j,:));
        %     end
        % simpplest rescaling
%        An=rescaling(temp);

        temp1=struct2cell(temp0);
        temp2=cell2mat(temp1);
        temp2=reshape(temp2,[1 numel(temp2)]);
        Features=[Features,temp2];
    end
    ObjectsFeatures(FIdx+i,:)=Features;
end
FIdx=size(ObjectsFeatures,1);
CasePoolIdx{2}=[lastIdx:FIdx];
lastIdx=FIdx+1;

%% Normal
load('normal.mat');  %%146
for i=1:size(AllFeatures,2)
    Features=[];
    for j=1:size(AllFeatures,1)
        temp0=AllFeatures{j,i}; 
        
        % scaling to unit length
        %     for j=1:size(A,1)
        %         temp2=A(j,:)/norm(A(j,:));
        %     end
        % simpplest rescaling
%        An=rescaling(temp);
        temp1=struct2cell(temp0);
        temp2=cell2mat(temp1);
        temp2=reshape(temp2,[1 numel(temp2)]);
        Features=[Features,temp2];
    end
    ObjectsFeatures(FIdx+i,:)=Features;
end
FIdx=size(ObjectsFeatures,1);
CasePoolIdx{3}=[lastIdx:FIdx];
ObjectsFeatures(:,63:88)=[];   %% to remove unused epidermis features
save('ObjectsFeatures.mat','ObjectsFeatures','CasePoolIdx');
end