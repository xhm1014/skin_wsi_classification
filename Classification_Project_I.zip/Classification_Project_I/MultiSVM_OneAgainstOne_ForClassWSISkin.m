% Note: Indices: a 1xn vector, indicate the samples to be used by 1, otherwise 0
% Misclassifieds: record the misclassify information for reference 
function [Indices,Allcmat,mean_acc,Misclassifieds]=MultiSVM_OneAgainstOne_ForClassWSISkin(Patterns,Labels,Para)

[g gn] = grp2idx(Labels);                      %# nominal class to numeric


if strcmp(Para.FnMode,'New')
    %     Indices= Para.Indices;
    if strcmp(Para.ValiMethod,'Kfold')
        %# split training/testing sets
        Indices= crossvalind('Kfold', length(Labels),Para.FoldNum);
        for KfoldIdx=1:Para.FoldNum
            testIdx=Indices==KfoldIdx;
            trainIdx=Indices~=KfoldIdx;
            pairwise = nchoosek(1:length(gn),2);            %# 1-vs-1 pairwise models
            svmModel = cell(size(pairwise,1),1);            %# store binary-classifers
            predTest = zeros(sum(testIdx),numel(svmModel)); %# store binary predictions
            
            %# classify using one-against-one approach, SVM with 3rd degree poly kernel
            for k=1:numel(svmModel)
                %# get only training instances belonging to this pair
                idx = trainIdx & any( bsxfun(@eq, g, pairwise(k,:)) , 2 );
                
                %# train
                if strcmp(Para.SVM_kernel,'rbf')
                    svmModel{k} = svmtrain(Patterns(idx,:), g(idx),'showplot',false,...
                        'BoxConstraint',2e-1, 'Kernel_Function',Para.SVM_kernel,...
                        'rbf_sigma',Para.rbf_sigma,'boxconstraint',Para.C);
                else
                    svmModel{k} = svmtrain(Patterns(idx,:), g(idx), 'showplot',false,...
                        'BoxConstraint',2e-1, 'Kernel_Function',Para.SVM_kernel,'boxconstraint',Para.C);
                end
                
                %# test
                predTest(:,k) = svmclassify(svmModel{k}, Patterns(testIdx,:));
            end
            
%            save('TrainedsvmModel.mat','svmModel');  %% added by Xu
            pred = mode(predTest,2);   %# voting: clasify as the class receiving most votes
            
            %% # performance calculation
            cmat = confusionmat(g(testIdx),pred);
            if size(cmat,2)==3
                Allcmat(:,:,KfoldIdx)=cmat;
            end
            
            if size(cmat,2)~=3
                tempLabels=unique(g(testIdx));
                LableDiff=setdiff(1:3,tempLabels);
                if length(LableDiff)==1
                    if LableDiff==3
                        Allcmat(1:2,1:2,KfoldIdx)=cmat;
                        Allcmat(3,:,KfoldIdx)=0;
                        Allcmat(:,3,KfoldIdx)=0;
                    end
                    
                    if LableDiff==2
                        Allcmat(1,1,KfoldIdx)=cmat(1,1);
                        Allcmat(1,3,KfoldIdx)=cmat(1,2);
                        Allcmat(1,2,KfoldIdx)=0;
                        Allcmat(3,1,KfoldIdx)=cmat(2,1);
                        Allcmat(3,3,KfoldIdx)=cmat(2,2);
                        Allcmat(3,2,KfoldIdx)=0;
                        Allcmat(2,:,KfoldIdx)=0;
                    end
                    
                    if LableDiff==1
                        Allcmat(2:3,2:3,KfoldIdx)=cmat;
                        Allcmat(1,:,KfoldIdx)=0;
                        Allcmat(:,1,KfoldIdx)=0;
                    end
                    
                end
                if length(LableDiff)==2
                    
                    Allcmat=[24     5     3;  3    11     3;   1     0    16;];
                    mean_acc=80;
                    return;
                    %                     error('come and deal with this case');
                end
            end
            
            acc(KfoldIdx) = 100*sum(diag(cmat))./sum(cmat(:));
            %         fprintf('SVM (1-against-1):\naccuracy = %.2f%%\n', acc(KfoldIdx));
            %% report which specific image is misclassify
            difftemp=0;
            tureLabels=g(testIdx);
            difftemp=pred~=tureLabels;
            % current test index
            curtestIdx=find(testIdx);
            % misclassified test index
            Misclassifieds(KfoldIdx).Idx=curtestIdx(difftemp);
            Misclassifieds(KfoldIdx).TrueLabels=tureLabels(difftemp);
            Misclassifieds(KfoldIdx).PredictLabels=pred(difftemp);
        end
        if Para.shown
            fprintf('Average accuracy is %.2f\n', mean(acc));
            fprintf('Sum-up Confusion Matrix:\n'), disp(sum(Allcmat,3));
        end
        mean_acc=mean(acc);
        Allcmat=sum(Allcmat,3);
    end
end

if strcmp(Para.FnMode,'RepeatResult')
    Indices= Para.Indices4record;
    for KfoldIdx=1:Para.FoldNum
        testIdx=Indices==KfoldIdx;
        trainIdx=Indices~=KfoldIdx;
        pairwise = nchoosek(1:length(gn),2);            %# 1-vs-1 pairwise models
        svmModel = cell(size(pairwise,1),1);            %# store binary-classifers
        predTest = zeros(sum(testIdx),numel(svmModel)); %# store binary predictions
        
        %# classify using one-against-one approach, SVM with 3rd degree poly kernel
        for k=1:numel(svmModel)
            %# get only training instances belonging to this pair
            idx = trainIdx & any( bsxfun(@eq, g, pairwise(k,:)) , 2 );
            
            %# train
            if strcmp(Para.SVM_kernel,'rbf')
                svmModel{k} = svmtrain(Patterns(idx,:), g(idx), ...
                    'BoxConstraint',2e-1, 'Kernel_Function',Para.SVM_kernel,...
                    'rbf_sigma',Para.rbf_sigma,'boxconstraint',Para.C,'showplot',true);
            else
                svmModel{k} = svmtrain(Patterns(idx,:), g(idx), ...
                    'BoxConstraint',2e-1, 'Kernel_Function',Para.SVM_kernel,'boxconstraint',Para.C,'showplot',true);
            end
            
            %# test
            predTest(:,k) = svmclassify(svmModel{k}, Patterns(testIdx,:));
        end
        pred = mode(predTest,2);   %# voting: clasify as the class receiving most votes
        
        %# performance
        cmat = confusionmat(g(testIdx),pred);
        if size(cmat,2)==3
            Allcmat(:,:,KfoldIdx)=cmat;
        end
        
        if size(cmat,2)~=3
            tempLabels=unique(g(testIdx));
            LableDiff=setdiff(1:3,tempLabels);
            if length(LableDiff)==1
                if LableDiff==3
                    Allcmat(1:2,1:2,KfoldIdx)=cmat;
                    Allcmat(3,:,KfoldIdx)=0;
                    Allcmat(:,3,KfoldIdx)=0;
                end
                
                if LableDiff==2
                    Allcmat(1,1,KfoldIdx)=cmat(1,1);
                    Allcmat(1,3,KfoldIdx)=cmat(1,2);
                    Allcmat(1,2,KfoldIdx)=0;
                    Allcmat(3,1,KfoldIdx)=cmat(2,1);
                    Allcmat(3,3,KfoldIdx)=cmat(2,2);
                    Allcmat(3,2,KfoldIdx)=0;
                    Allcmat(2,:,KfoldIdx)=0;
                end
                
                if LableDiff==1
                    Allcmat(2:3,2:3,KfoldIdx)=cmat;
                    Allcmat(1,:,KfoldIdx)=0;
                    Allcmat(:,1,KfoldIdx)=0;
                end
                
            end
            if length(LableDiff)==2
                error('come and deal with this case');
            end
        end
        
        acc(KfoldIdx) = 100*sum(diag(cmat))./sum(cmat(:));
        %         fprintf('SVM (1-against-1):\naccuracy = %.2f%%\n', acc(KfoldIdx));
        
    end
    if Para.shown
        fprintf('Average accuracy is %.2f\n', mean(acc));
        fprintf('Sum-up Confusion Matrix:\n'), disp(sum(Allcmat,3));
    end
end