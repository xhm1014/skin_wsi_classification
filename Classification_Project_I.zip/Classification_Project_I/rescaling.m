function An=rescaling(A)
 % simpplest rescaling
    vmin=min(A,[],2);
    nm=repmat(vmin,1,size(A,2));
    vmax=max(A,[],2);
    dm=repmat((vmax-vmin),1,size(A,2));
    An=(A-nm)./dm;
end