%%------------------------%%
% Author Hongming Xu
% ECE, University of Alberta


function [maskAllCells_ATLRRS]=SegNucleiInEpi(maskConfLHR,RC,RC_ori)
tempCC=bwconncomp(maskConfLHR);

for i =1 :tempCC.NumObjects
    List_LHR=tempCC.PixelIdxList(i);
end

RC_LHR=RC(List_LHR{1});
TWhiteColor=210;

%% adaptive thresholding for comparision
%% !!!!! I.F. !!!!!
meanValueofEpi=mean(RC(maskConfLHR));
RC(~maskConfLHR)=meanValueofEpi+30;
% show(RC);
ws=40; %window size
maskRC_adThresh=adaptivethreshold(RC,ws,0.02,0);
% LshowObjonlybyLogicalMask(~maskRC_adThresh,RC,6,2);
maskRC_Thresh=~maskRC_adThresh;
% maskAllCells_AD=maskRC_Thresh;
% maskAllCells_AD=imopen(maskAllCells_AD,strel('disk',2));

%% first remove the super big area which deemed as keratin area
cc = bwconncomp(maskRC_Thresh,4);
stats = regionprops(cc, 'Area');
idx = find([stats.Area] < 6500);
maskRC_Thresh= ismember(labelmatrix(cc), idx);

%% adjust the threshold for big area
% if the thresholding is good then the image will have many small pieces
% other wise, adjust the thresh value.
% first check if there is any large regions
tempCC=bwconncomp(maskRC_Thresh,4);
Area=zeros(1,tempCC.NumObjects);
for i=1:tempCC.NumObjects
    Area(i)=length(tempCC.PixelIdxList{i});
end