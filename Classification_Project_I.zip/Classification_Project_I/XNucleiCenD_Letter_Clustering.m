%%----------------------%%
% Input
%     R: image channel (current implementation using Red Channel)
%    C_mask3: the foreground is nuclei which clump together or have
%    concave shape
% Output:
%    bs4: the binary image with nuclei centers as foreground
% Written by Hongming Xu
% ECE U of A
% feel free to use it
%%---------------------%%


function [cs]=XNucleiCenD_Letter_Clustering(R,C_mask3,largeSigma,smallSigma)

%% Method (i) Multi-Scale Gaussian of Laplacian
% R_hat=255-R;
% Para.Set_Sigma=[4:1:8];
% Para.TargetColor='bright';
% Para.Method='Sumup';
% % %Para.Method='PickMax';
% [IM_resN,IM_res,AllIM_res]=LNorMultiScaleLoG_bolb(R_hat,Para);
% bt=imregionalmax(IM_resN);
% bt(~C_mask3)=0;
% bs4=bt;


%% Method (ii)
%% Method (iii) gGoG

R_hat=double(255-R);
thetaStep=pi/9;    % thetaStep
%thetaStep=pi/4;    % thetaStep
largeSigma=8;smallSigma=4; % Sigma value
sigmaStep=-1;              % Sigma step
kerSize=largeSigma*4;    % Kernel size
alpha = 1;

% Sigmas=[3:1:9];
% n=largeSigma*4;
% F=zeros(round(n+1),round(n+1));
% for i=1:length(Sigmas)
%     sigma=Sigmas(i);
%     k=sigma^2*fspecial('LoG',round(n+1),sigma);
%     F=F+k;
% end
% aggregated_response =imfilter(double(R),F,'replicate'); 
% aggregated_response_norm = scaleNormalization(aggregated_response, 0, 255);                                                                                       
% bt=imregionalmax(aggregated_response_norm);
% bt(~C_mask3)=0;
% bfs=bt;

%% fast old version
% [aggregated_response] = Xaggregate_gLoG_filter_response2(R_hat, largeSigma, smallSigma, sigmaStep,thetaStep, kerSize, alpha);
% bfs=zeros(size(R));
% for i=1:size(aggregated_response,3)
%     aggregated_response1=aggregated_response(:,:,i);
%     aggregated_response_norm = scaleNormalization(aggregated_response1, 0, 255);                                                                                       
%     bt=imregionalmax(aggregated_response_norm);
%     bt(~C_mask3)=0;
%     
%     if i==1
%         bfs=bt;
%     else
%         bt_dilate=imdilate(bfs,strel('disk',round(smallSigma*1.5)));
%         bt_and=bt_dilate&bt;
%         bt_temp=bt-bt_and;
%                
%         bfs=bfs|bt_temp;
%        end
%     
% end

%% modified but low efficient version
[aggregated_response] = Xaggregate_gLoG_filter_response2_V2(R_hat, largeSigma, smallSigma, sigmaStep,thetaStep, kerSize, alpha); %% summation with each direction
%[aggregated_response] = Xaggregate_gLoG_filter_Clustering(R_hat, largeSigma, smallSigma, sigmaStep,thetaStep, kerSize, alpha); %% without summation
%bcur=zeros(size(R)); %% for generating figures
X=[;];
Y=[];
for i=1:size(aggregated_response,3)
    aggregated_response1=aggregated_response(:,:,i);
    aggregated_response_norm = scaleNormalization(aggregated_response1, 0, 255);                                                                                       
    bt=imregionalmax(aggregated_response_norm);
    
%    bcur=bcur|bt;   %% for generating figures
    
    bt(~C_mask3)=0;
    [r,c]=find(bt);
    X=[X,[r';c']];
    ind=sub2ind(size(R),r,c);
    Y=[Y,aggregated_response_norm(ind)'];
    
   
    
end


% [r,c]=find(bcur);
% X=[r';c'];
bandwidth=6;
%bandwidth=4.8;
%bandwidth=5.4;
%bandwidth=6.6;
% bandwidth=7.2;
[clustCent,point2cluster,clustMembsCell] = MeanShiftCluster(X,bandwidth);

cs=[];
for i=1:length(clustMembsCell)
    temp=clustMembsCell{i,1};
    [~,ind]=max(Y(temp));
    index=temp(ind);
    cs=[cs,X(:,index)];
end

% bcur=logical(zeros(size(R)));
% ind=sub2ind(size(R),cs(1,:),cs(2,:));
% bcur(ind)=1;
% %merge too close seeds (avoids over-segmentations
% bt2=imdilate(bcur,strel('disk',1));
% s=regionprops(bt2,'centroid');
% centroids=cat(1,s.Centroid);
% %cs3=centroids(:,1);
% %rs3=centroids(:,2);
% linearInd=sub2ind(size(bt2),round(centroids(:,2)),round(centroids(:,1)));
% btemp=logical(zeros(size(bt2)));
% btemp(linearInd)=1;
% bs4=btemp&C_mask3; % remove the merged seeds outside nuclei region

end