%% this is the second version
%% the white background is first removed, and then k-means
%% segment blue and pink color
function [Nmask3,NImask]=kmeans_seg2(I,Dermis,ac)
%convert RGB image into LAB color space
cform=makecform('srgb2lab');
lab_I=applycform(I,cform);
R=I(:,:,1);
TWhite=0.95;
RSf=~im2bw(R,TWhite);
bw=RSf&Dermis;

% k-means clustering
ind=find(bw);
a=double(lab_I(:,:,2));b=double(lab_I(:,:,3));c=double(lab_I(:,:,1));
ab=[a(ind),b(ind),c(ind)];
nColors=2;
[cluster_idx,cluster_center]=kmeans(ab,nColors,'Replicates',1);

%% for debugging
% temp=zeros(size(Dermis));
% index=find(cluster_idx==1);
% ind2=ind(index);
% temp(ind2)=1;
% temp3d=cat(3,temp,temp,temp);
% Iimg=I.*uint8(temp3d);

% nuclei segmentation
[~,idx]=min(cluster_center(:,2));
%index=cluster_idx==idx;
%ind2=ind(index);

%% HGMR module
R_hat=255-R;
% Opening by reconstruction
% S = [0 0 1 1 1 0 0;...
%     0 1 1 1 1 1 0;...
%     1 1 1 1 1 1 1;...
%     1 1 1 1 1 1 1;...
%     1 1 1 1 1 1 1;...
%     0 1 1 1 1 1 0;...
%     0 0 1 1 1 0 0];

S = [0 0 1 0 0;...
     0 1 1 1 0;...
     1 1 1 1 1 ;...
     0 1 1 1 0;...
     0 0 1 0 0];
Re=imerode(R_hat,S);
fRe=imreconstruct(Re,R_hat);

% Closing-by-Reconstruction
fRerc=imcomplement(fRe);
fRerce=imerode(fRerc,S);
fRercbr=imcomplement(imreconstruct(fRerce,fRerc));

R=255-fRercbr;

%R_blue=R(ind2);
%thr=graythresh(R_blue);
thr=0.57;  %% manually determined better than Ostu's method

Nmask1=im2bw(R,thr);
Nmask1=Nmask1|(~Dermis);
index2=cluster_idx~=idx;
ind2=ind(index2);
Nmask1(ind2)=1;
Nmask1=imopen(~Nmask1,strel('disk',2));
Nmask1=bwareaopen(Nmask1,round(ac),8);
Nmask1=imfill(Nmask1,'holes');

%% local threshold segmentation
[label2,n2]=bwlabel(Nmask1);
stats2=regionprops(label2,'BoundingBox');
Nmask2=Nmask1;
%imshow(R)
[r,c]=size(Nmask2);
for j=1:n2
    x=floor(stats2(j).BoundingBox(1));
    y=floor(stats2(j).BoundingBox(2));
    w=floor(stats2(j).BoundingBox(3));
    h=floor(stats2(j).BoundingBox(4));
    if x<1   %% make sure the bounding box is within the image
        x=1;
    end
    if y<1
        y=1;
    end
    if y+h>r
        y2=r;
    else
        y2=y+h;
    end
    if x+w>c
        x2=c;
    else
        x2=x+w;
    end
    tr=R(y:y2,x:x2);
    rr=im2bw(tr,graythresh(tr));
    Nmask2(y:y2,x:x2)=Nmask1(y:y2,x:x2)&(~rr);
%      hold on,
%      plot(stats2(j).BoundingBox(1),stats2(j).BoundingBox(2),'r*');
%      rectangle('Position',[stats2(j).BoundingBox(1),stats2(j).BoundingBox(2),stats2(j).BoundingBox(3),stats2(j).BoundingBox(4)],...
%         'EdgeColor','g','LineWidth',2);
end
Nmask2=imopen(Nmask2,strel('disk',2));
Nmask2=bwareaopen(Nmask2,round(ac),8);
Nmask2=imfill(Nmask2,'holes');

%% for debugging
% temp3d=cat(3,Nmask1,Nmask1,Nmask1);
% Iimg=I.*uint8(temp3d);
% show(I)
% B=bwboundaries(Nmask2);
% for j=1:length(B)
%     b1=B{j};
%     hold on,plot(b1(:,2),b1(:,1),'g-','LineWidth',2);
% end

%% find isolated nuclei centers with high fittness of convex shape
[label3]=bwlabel(Nmask2);
stats3=regionprops(label3,'Solidity');
s3=cat(1,stats3.Solidity);
ind3=find(s3>0.95);
NImask=ismember(label3,ind3);
%c4=regionprops(NImask,'centroid');
%centroids4=cat(1,c4.Centroid);
% cs4=centroids4(:,1);
% rs4=centroids4(:,2);
Nmask3=Nmask2-NImask;
end