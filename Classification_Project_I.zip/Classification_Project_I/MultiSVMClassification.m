function acc=MultiSVMClassification(svmModel,x,y)

predTest=zeros(size(x,1),numel(svmModel));

for k=1:numel(svmModel)
    
    %# test
    predTest(:,k)=svmclassify(svmModel{k},x);
end

%# voting for classification
pred=mode(predTest,2);

%# performance evaluation
cmat=confusionmat(grp2idx(y),pred);
acc=sum(diag(cmat))./sum(cmat(:));

end