function [Nmask3,NImask]=kmeans_seg(I,Dermis,ac)
%convert RGB image into LAB color space
cform=makecform('srgb2lab');
lab_I=applycform(I,cform);
% k-means clustering
ind=find(Dermis);
a=double(lab_I(:,:,2));b=double(lab_I(:,:,3));
ab=[a(ind),b(ind)];
nColors=3;
[cluster_idx,cluster_center]=kmeans(ab,nColors,'Replicates',2);

%% for debugging
% temp=zeros(size(Dermis));
% index=find(cluster_idx==1);
% ind2=ind(index);
% temp(ind2)=1;
% temp3d=cat(3,temp,temp,temp);
% Iimg=I.*uint8(temp3d);

% nuclei segmentation
[~,idx]=min(cluster_center(:,2));
L=lab_I(:,:,1);
index=cluster_idx==idx;
ind2=ind(index);
L_blue=L(ind2);
thr=graythresh(L_blue);

Nmask1=im2bw(L,thr);
Nmask1=Nmask1|(~Dermis);
index2=cluster_idx~=idx;
ind2=ind(index2);
Nmask1(ind2)=1;
Nmask1=imopen(~Nmask1,strel('disk',2));
Nmask1=bwareaopen(Nmask1,round(ac),8);
Nmask1=imfill(Nmask1,'holes');

%% local threshold segmentation
%R=I(:,:,1);
[label2,n2]=bwlabel(Nmask1);
stats2=regionprops(label2,'BoundingBox');
Nmask2=Nmask1;
%imshow(R)
for j=1:n2
    x=floor(stats2(j).BoundingBox(1));
    y=floor(stats2(j).BoundingBox(2));
    w=floor(stats2(j).BoundingBox(3));
    h=floor(stats2(j).BoundingBox(4));
    if x<1   %% make sure the bounding box is within the image
        x=1;
    end
    if y<1
        y=1;
    end
    tr=L(y:y+h,x:x+w);
    rr=im2bw(tr,graythresh(tr));
    Nmask2(y:y+h,x:x+w)=Nmask1(y:y+h,x:x+w)&(~rr);
%      hold on,
%      plot(stats2(j).BoundingBox(1),stats2(j).BoundingBox(2),'r*');
%      rectangle('Position',[stats2(j).BoundingBox(1),stats2(j).BoundingBox(2),stats2(j).BoundingBox(3),stats2(j).BoundingBox(4)],...
%         'EdgeColor','g','LineWidth',2);
end
Nmask2=imopen(Nmask2,strel('disk',2));
Nmask2=bwareaopen(Nmask2,round(ac),8);
Nmask2=imfill(Nmask2,'holes');

%% for debugging
% temp3d=cat(3,Nmask1,Nmask1,Nmask1);
% Iimg=I.*uint8(temp3d);
% show(I)
% B=bwboundaries(Nmask2);
% for j=1:length(B)
%     b1=B{j};
%     hold on,plot(b1(:,2),b1(:,1),'g-','LineWidth',2);
% end

%% find isolated nuclei centers with high fittness of convex shape
[label3]=bwlabel(Nmask2);
stats3=regionprops(label3,'Solidity');
s3=cat(1,stats3.Solidity);
ind3=find(s3>0.95);
NImask=ismember(label3,ind3);
%c4=regionprops(NImask,'centroid');
%centroids4=cat(1,c4.Centroid);
% cs4=centroids4(:,1);
% rs4=centroids4(:,2);
Nmask3=Nmask2-NImask;
end