%---annotation---%
% The main function for classification skin images
% University of Alberta
% Hongming Xu
%---end---%

% this script is used for biopsy classification 
% 1-Melanoma 2-Neavus 3-Normal
function Features_Classification
clear all; clc;
%cd C:\Users\mxu\Dropbox\Public\Classification_Project_I\Features
cd C:\Users\Jorge\Dropbox\Public\Classification_Project\features

load('ObjectsFeatures.mat');

LabelPool=[1:3];
%ObjectsFeatures=ObjectsFeatures(:,14:73);
FeatureDim=size(ObjectsFeatures,2);

for i=1:size(CasePoolIdx,2)
    curCaseIdx=CasePoolIdx{i};
    ObjectsFeatures(curCaseIdx,FeatureDim+1)=LabelPool(i);
end

%% using SVM for multi-class classification
Para.ValiMethod='Kfold';
Para.FoldNum=10;

SVM_kernelPool={'linear','quadratic','polynomial','rbf','mlp'};
Para.SVM_kernel=SVM_kernelPool{1};
Para.rbf_sigma=1;
Para.C=1;
Para.FnMode='New';
Para.shown=0;

TrailNum=100;
for Tind=1:TrailNum
    [~,Allcmat(:,:,Tind),Allmean_acc(Tind)]=MultiSVM_OneAgainstOne_ForClassWSISkin(ObjectsFeatures(:,1:end-1),ObjectsFeatures(:,end),Para);
end
end