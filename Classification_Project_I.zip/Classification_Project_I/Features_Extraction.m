%---annotation---%
% The main function for extracting features from skin images
% University of Alberta
% Hongming Xu
%---end---%



function  Features_Extraction
%clc;
%outputpath='C:\Users\Jorge\Desktop\Hongming\Classification_Project_I\Features\'
outputpath='C:\Users\mxu\Dropbox\Public\Classification_Project_I\Features\'
cd C:\Database_I\Melanoma
%cd C:\Database_I\Nevus\
%cd C:\Database_I\Normal
list=dir('*.mat');
directory=pwd;
index=1;

for i=1:length(list)
    imageName=list(i).name;
    load(imageName);
    for k=1:length(AllIMTiles)
        if ~isempty(AllIMTiles{k})
            I=AllIMTiles{k};
            
            %% step 1   color normalization
            [Inorm2,H2,E2]=normalizeStaining(I);
            
            %% step 2 dermis and epidermis segmentation
            ar=2000;                                                      % remove samll connected areas
            if strcmp(directory(end-4:end),'Nevus')
                ds=0.25;                                                  % for nevus downsampling
            else
                ds=0.125;                                                 % for melanoma and normal downsampling
            end
            
            R=Inorm2(:,:,1);                                               % use R channel basci processing
            [Epidermis,Dermis]=XDermis_Epidermis(R,ds,ar);
            
            %% fill the holes assume the layout is horizontal
            temp=Epidermis|Dermis;
            dmask1=padarray(temp,[1 1],1,'pre');
            dmask1=imfill(dmask1,'holes');
            dfill1=dmask1(2:end,2:end);
            dmask2=padarray(padarray(dfill1,[1 0],1,'pre'),[0 1],1,'post');
            dmask2=imfill(dmask2,'holes');
            dmask2=dmask2(2:end,1:end-1);
            Dermis=dmask2-Epidermis;
            Dermis=bwareaopen(Dermis,ar);
            %             %% for debugging
            %             blm1=bwperim(Epidermis);
            %             overlay1=imoverlay(R,blm1,[0 1 0]);
            %             blm2=bwperim(Dermis);
            %             overlay2=imoverlay(overlay1,blm2,[0 0 1]);
            %             s0='melanoma';
            %             s1=num2str(index);
            %             s2='.tif';
            %             fname=strcat(s0,s1,s2);
            %             outputfilename=[outputpath,fname];
            %             imwrite(overlay2,outputfilename);
%             
                        %% step 3 epidermis features construction
                        [r,~]=find(Epidermis); %% assume horizontoal layour
                        rmin=min(r);rmax=max(r);
                        if rmax+5>size(Epidermis,1)
                            rr=size(Epidermis,1);
                        else
                            rr=rmax+5;
                        end
                        epi_submask=Epidermis(rmin-5:rr,:);
                        IE=I(rmin-5:rr,:,:);
                        bwmask3=cat(3,epi_submask,epi_submask,epi_submask);
                        AllTileMask_finer{1}=epi_submask;
            
                        %    AllTileMask_finer{1}=Epidermis;
                        AnalysisDirection='BU';    % buttom to up analysis
                        ResAtcurAnaMag=0.372; % micrometer per pixel
                        [MorphoInfo,AllPtsonBnd_Basal,AllPtsonBnd_Keratin]=...
                            LgetEpidermisMorphoInfo(AllTileMask_finer,AnalysisDirection,ResAtcurAnaMag);
                        %
                        %% -- nuclei segmentation starts here ---%%
                        IE(~bwmask3)=0;
                        AllIMTiles_finer{1}=IE;
                        [AllBWInIMTiles4Nuclei,AllCentroidInIMTiles4Nuclei]=LSegNuclei4AllIMTiles(AllIMTiles_finer,AllTileMask_finer);
            
%                         %% for debugging
%                         temp=AllBWInIMTiles4Nuclei{1};
%                         blm=bwperim(temp);
%                         overlay1=imoverlay(IE,blm,[1 1 0]);
%                         s0='nevus';
%                         s1=num2str(index);
%                         s2='.tif';
%                         fname=strcat(s0,s1,s2);
%                         outputfilename=[outputpath,fname];
%                         imwrite(overlay1,outputfilename);

                        %% cal the nuclei counting info and features for the Epi sub layer
                        [Nuclei_O,Nuclei_M,Nuclei_I]=LgetCountingInfo4EpiSubLayer(AllCentroidInIMTiles4Nuclei,AllPtsonBnd_Keratin,MorphoInfo,ResAtcurAnaMag,'local');
                        Nuclei_F=LgetFeaturesInfo4EpisubLayer(AllCentroidInIMTiles4Nuclei,AllBWInIMTiles4Nuclei);
                   
                                    %% -- melanocytes segmentaton starts here ---%%
                                    MelaDetectPar=struct('Method','RLS','TAreaRatio',.6,'TsmalNucleiArea',80);
                                    [AllBWInIMTiles4Melanocyte,AllCentroidInIMTiles4Melanocyte]...
                                        =LSegMelanocytes4AllIMTiles(AllIMTiles_finer, AllTileMask_finer,AllBWInIMTiles4Nuclei,MelaDetectPar);
%                         %% for debugging
%                         temp=AllBWInIMTiles4Melanocyte{1};
%                         blm=bwperim(temp);
%                         overlay1=imoverlay(overlay1,blm,[0 1 0]);
%                         s0='normal';
%                         s1=num2str(index);
%                         s2='.tif';
%                         fname=strcat(s0,s1,s2);
%                         outputfilename=[outputpath,fname];
%                         imwrite(overlay1,outputfilename)
%                         show(IE)
%                         temp=AllBWInIMTiles4Melanocyte{1};
%                         B=bwboundaries(temp);
%                         for j=1:length(B)
%                             b1=B{j};
%                             hold on,plot(b1(:,2),b1(:,1),'r-');
%                         end
                                    %% cal the mealnocytes counting info for the Epi sub layer
                                    [Mela_O,Mela_M,Mela_I]=LgetCountingInfo4EpiSubLayer(AllCentroidInIMTiles4Melanocyte,AllPtsonBnd_Keratin,MorphoInfo,ResAtcurAnaMag,'local');
                                    Mela_F=LgetFeaturesInfo4EpisubLayer(AllCentroidInIMTiles4Melanocyte,AllBWInIMTiles4Melanocyte);
            
                                    %%  13 features used by PR paper
                                    Table=[Nuclei_O Mela_O;Nuclei_M Mela_M;Nuclei_I Mela_I]; %% the number of melanocytes with keratinocytes
%                                     temp_MF=struct2cell(Mela_F);
%                                     MF=cell2mat(temp_MF);
%                                     AE=[Table(:,2)./Table(:,1);MF(9:length(MF))];
                                    mk=Table(:,2)./Table(:,1);
                                    mk(isnan(mk))=0;
                                    Rmk_F.outter=mk(1);
                                    Rmk_F.middle=mk(2);
                                    Rmk_F.inner=mk(3);
                                    
%             
                                    
            %%--Dermis features construction--%%
            %%---textural features in the dermis area---%%
%            HifMat=[];HafMat=[];
            for c=1:1                                                          %% only red channel
                His_F=Histogram_features(Inorm2,Dermis,c);                     %% histogram features
%                 HifMat=[HifMat;stat1'];
                Hara_F=Haralick_features(Inorm2,Dermis,c);                      %% Haralick features
%                 C5=struct2cell(stat2);
%                 temp=cell2mat(C5);
%                 temp1=reshape(temp,[numel(temp),1]);
%                 HafMat=[HafMat;temp1];
            end
            
            
            %% image binarization part
            ac=30;                                                             %% remove isolated pixels
            [Nmask,NImask]=Thresholding_seg2(Inorm2,Dermis,ac);                %% Predefined thresholding based binarization
            curC=regionprops(NImask,'centroid');
           
            %% gLoG based nuclei detection part
            Para.thetaStep=pi/9;
            Para.largeSigma=8;
            Para.smallSigma=4;
            Para.sigmaStep=-1;
            Para.kerSize=Para.largeSigma*4;
            Para.bandwidth=5;
            cs=NucleiSeedsDetection_gLoG(R,Nmask,Para);
            
            %% radial line scanning based segmentation
            %% do not consider the seeds on image borders as those are parts of nuclei
            ind1=find(cs(:,1)<3 | (size(R,1)-cs(:,1))<3);
            if ~isempty(ind1)
                cs(ind1,:)=[];
            end
            ind1=find(cs(:,2)<3 | (size(R,2)-cs(:,2))<3);
            if ~isempty(ind1)
                cs(ind1,:)=[];
            end
            rs5=cs(:,1);cs5=cs(:,2);
            
            ss2=7:1:11;
            R1= imfilter(double(R),fspecial('Gaussian',[5 5],1),'same','conv','replicate');
            
            Rd0=[];
            St0=[];
            for j=1:length(rs5)
                cx=cs5(j);cy=rs5(j);
                [bw,~]=DP_snake_Seg(double(R1),cx,cy,ss2,Nmask);
                bw=imclose(logical(bw),strel('disk',1));
                
                if sum(bw(:))>0
                    %%(i) regional descriptors
                    Rd=regionprops(bw,'Area','Eccentricity','MajorAxisLength','MinorAxisLength','Perimeter');
                    per=Rd.Perimeter;
                    area=Rd.Area;
                    pr=per/(sqrt(area));              % perimeter ratio to measure boundary irregularities
                    Rd.Pratio=pr;
                    Rd0=[Rd0;Rd];
                    
                    %%(ii) statistical texture features
                    %             % average intensity, average contrast,smoothness, third moment, uniformity,
                    %             % and entropy
                    tm=R(bw);     %% original red channel
                    St=statxture(tm);
                    St0=[St0,St'];
                    
                    %% (iii) graph features
                    curCC=regionprops(bw,'centroid');
                    curC=[curC;curCC];
                end
            end
            
            
            %% wathershed based segmentation
            %             fm=zeros(size(R));
            %             ind=sub2ind(size(R),cs(:,1),cs(:,2));
            %             fm(ind)=1;
            %             [bnf,~] = XWaterShed(Nmask,fm);
            %
            %             %             %% for debugging
            %             %             c4=regionprops(NImask,'centroid');
            %             %             centroids4=cat(1,c4.Centroid);
            %             %             hold on,plot(centroids4(:,1),centroids4(:,2),'y+');
            %             %             hold on,plot(cs(2,:),cs(1,:),'g+');
            %             %             hold off;
            %
            %             %             blm=bwperim(Nmask);  % for debugging to observe the binarization results
            %             %             bb=bwperim(NImask);
            %             %             ind5=find(bb);
            %             %             bb1=bwperim(Epidermis);
            %             %             ind6=find(bb1);
            %             %             blm(ind5)=1;
            %             %             blm(ind6)=1;
            %             %             overlay1=imoverlay(I,blm,[1 1 0]);
    

            %              bw_nuclei=NImask|bnf;  % final binary result
            %              bwn=bwareaopen(bw_nuclei,ac,4); % remove small nuclei regions
            %
%             % %             %% for debugging
%             % %                         blm1=bwperim(bwn);
%             % %                         overlay1=imoverlay(Inorm2,blm1,[0 1 0]);
%                                     s0='normal';
%                                     s1=num2str(index);
%                                     s2='.tif';
%                                     fname=strcat(s0,s1,s2);
%                                     outputfilename=[outputpath,fname];
%                                     imwrite(overlay1,outputfilename);
            
                                    %%(i) regional descriptors
                                    Rd1=regionprops(NImask,'Area','Eccentricity','MajorAxisLength','MinorAxisLength','Perimeter');
                                    per=[Rd1.Perimeter];   %% use brackets to get all values
                                    area=[Rd1.Area];
                                    pr=per./(sqrt(area));  %% perimeter ratio to measure boundary irregularities
                                    prArray=num2cell(pr);
                                    [Rd1.Pratio]=deal(prArray{:});
                                    Rd=[Rd1;Rd0];
                                    Cf=struct2cell(Rd);
                                    RdMat=cell2mat(Cf);   %% 6xN Array
                                    Rdm=mean(RdMat,2);
                                    Rds=std(RdMat,[],2);
                                    Rd_F.mean_area=Rdm(1);
                                    Rd_F.mean_eccentricity=Rdm(2);
                                    Rd_F.mean_majoraxislength=Rdm(3);
                                    Rd_F.mean_minoraxislength=Rdm(4);
                                    Rd_F.mean_perimeter=Rdm(5);
                                    Rd_F.mean_pratio=Rdm(6);
                                    Rd_F.std_area=Rds(1);
                                    Rd_F.std_eccentricity=Rds(2);
                                    Rd_F.std_majoraxislength=Rds(3);
                                    Rd_F.std_minoraxislength=Rds(4);
                                    Rd_F.std_perimeter=Rds(5);
                                    Rd_F.std_pratio=Rds(6);
                           %         RdfMat=[Rdm;Rds];
            %             %(ii) statistical texture features
                        % average intensity, average contrast,smoothness, third moment, uniformity,
                        % and entropy
                        St1=mstatxture(R,NImask); % from red channel
                        StMat=[St1,St0];
                        Stm=mean(StMat,2);
                        Sts=std(StMat,[],2);
                        St_F.mean_intensity=Stm(1);
                        St_F.mean_contrast=Stm(2);
                        St_F.mean_smoothness=Stm(3);
                        St_F.mean_thirdmoment=Stm(4);
                        St_F.mean_uniformity=Stm(5);
                        St_F.mean_entropy=Stm(6);
                        St_F.std_intensity=Sts(1);
                        St_F.std_contrast=Sts(2);
                        St_F.std_smoothness=Sts(3);
                        St_F.std_thirdmoment=Sts(4);
                        St_F.std_uniformity=Sts(5);
                        St_F.std_entropy=Sts(6);
                       % StfMat=[Stm;Sts];
           
                      %% (iii) Delaunay and Voronoi diagram features
%                       curC=regionprops(NImask,'centroid');
                        curCentroid=cat(1,curC.Centroid);
                        curCentroid(:,[1,2])=curCentroid(:,[2,1]);      %swap two columns
                        curCentroidCell{1}=curCentroid;
                        Gf_F=graphfeats(curCentroidCell);
%                         Cf=struct2cell(Gff);
%                         GffMat=cell2mat(Cf);   %% 6x1 array

          
%% save extracted features
                                    AllFeatures{1,index}=His_F;                                          %%18
                                    AllFeatures{2,index}=Hara_F;                                          %%6
                                    AllFeatures{3,index}=Rd_F;                                          %% textural features 6
                                    AllFeatures{4,index}=St_F;                                          %% textural features 24
                                    AllFeatures{5,index}=Gf_F;                                          %% epidermis feaures 13
                                    AllFeatures{6,index}=Nuclei_F;
                                    AllFeatures{7,index}=Mela_F;
                                    AllFeatures{8,index}=Rmk_F;
            index=index+1
        end
    end
end
outfilename=sprintf('%s%s.mat',outputpath,'normal');
save(outfilename,'AllFeatures');