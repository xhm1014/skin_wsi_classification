%%----------------------%%
% Input
%     R: image channel (current implementation using Red Channel)
%     ds: image downsampling factor
%     ar: remove non-epidermis regions
% Output:
%    DC_mask: the foreground is dermis area
% Written by Hongming Xu
% ECE U of A
% feel free to use it
%%---------------------%%




function [Epidermis, Dermis]=XDermis_Epidermis(R,ds,ar)

% (i) remove white background pixels
RS=imresize(R,ds,'bilinear'); 
TWhite=0.95; % threshold to remove white pixels
RSf=im2bw(RS,TWhite); % remove white background pixels
RSf_hat=~RSf;

% (ii) segment epidermis area
temp=RS(RSf_hat);
TR=graythresh(temp);  % Otsu's thresholding
Rlogical=im2bw(RS,TR); % segment epidermis pixels
Rlogical=~Rlogical;

CC0=bwconncomp(Rlogical);
numPixels=cellfun(@numel,CC0.PixelIdxList);
[~,idx]=max(numPixels);
Rar=false(size(Rlogical));
Rar(CC0.PixelIdxList{idx})=1;
%Rar=bwareaopen(Rlogical,ar,4); 
Rac=imclose(Rar,strel('disk',5));
Rfill=imfill(Rac,'holes');
Epidermis=imresize(Rfill,[size(R,1),size(R,2)]);

% (iii) select the largest foreground
Mask1=RSf|Rfill; % the mask contains WHITE pixels and Epidermis area
RC_mask=imresize(Mask1,[size(R,1),size(R,2)]);
RC_mask=~RC_mask;
CC=bwconncomp(RC_mask);
numPixels=cellfun(@numel,CC.PixelIdxList);
[~,idx]=max(numPixels);
Dermis=false(size(RC_mask));
Dermis(CC.PixelIdxList{idx})=1;
end