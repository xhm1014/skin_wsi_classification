%% Manually select image tiles for classification

clear all;close all;
list=dir('*.mat');
for i=13:length(list)
    imageName=list(i).name;
    load(imageName);
    for j=1:length(AllIMTiles)
        show(AllIMTiles{j});
        close all;
    end
    
end