%% cal the Voronoi Diagram statistics/features
%%% x,y are all column vectors
function Features=LFeatures_VoronoiDiagram(x,y)

%% Calculate and plot triangulation
[v,c]=voronoin([x,y]);
idx=1;
p=[];
A=[];
for i = 1:length(c)
    if all(c{i}~=1)   % cal for all the bounded cells only
        curV=[];
        curVshift=[];
        % First, get co-ordinates
        curV=v(c{i},:);
%         figure
%         for kkk=1:length(curV)
%             
%             line([curV(kkk,1),curV(kkk+1,1)],[curV(kkk,2),curV(kkk+1,2)]);
%             pause();
%         end
        % Then, get lengths of polygon sides
        curVshift(1:size(curV,1)-1,:)=curV(2:end,:);
        curVshift(size(curV,1),:)=curV(1,:);
        
        sideLengths=sqrt( sum( (curVshift-curV).^2,2 ) );
        
        % Now get meta-statistics
        p(idx) = sum(sideLengths);                   % Perimeter
%         curV=flipud(curV);
%         curVshift=flipud(curVshift);        
        A(idx) = abs(.5*sum(curVshift(:,1).*curV(:,2)-curVshift(:,2).*curV(:,1))); % Area 
        idx=idx+1;
    end
    
    Features.Perimeter=p;
    Features.Area=A;
end